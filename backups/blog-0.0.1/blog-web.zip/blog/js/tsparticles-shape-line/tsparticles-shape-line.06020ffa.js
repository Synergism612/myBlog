class e{draw(e,a,n){e.moveTo(-n/2,0),e.lineTo(n/2,0)}getSidesCount(){return 1}}async function a(a){await a.addShape("line",new e)}export{a as l};
