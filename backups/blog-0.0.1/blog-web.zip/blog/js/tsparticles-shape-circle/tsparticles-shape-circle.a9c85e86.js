class a{draw(a,e,t){a.arc(0,0,t,0,2*Math.PI,!1)}getSidesCount(){return 12}}async function e(e){await e.addShape("circle",new a)}export{e as l};
