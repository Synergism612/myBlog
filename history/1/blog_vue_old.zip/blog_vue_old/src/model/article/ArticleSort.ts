/**
 * 文章排序字段
 */
export default [
  "creation_time",
  "modify_time",
  "views",
  "like_count",
  "comment_count",
];
