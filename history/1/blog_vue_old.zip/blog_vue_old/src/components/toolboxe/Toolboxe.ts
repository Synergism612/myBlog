export default class Toolboxe {
  show: boolean;
  lessen:boolean;
  full:boolean;
  catalog:boolean;
  forum:boolean;
  index: boolean;
  top: boolean;

  constructor() {
    this.show = false;
    this.lessen = false;
    this.full = false;
    this.catalog = false;
    this.forum = false;
    this.index = false;
    this.top = false;
  }
}
