export enum apiEnum {
  TIMEOUT = 2 * 10000, //超时时间 二十秒
  OVERDUE = 600, // 登录失效
  FAIL = 999, // 请求失败
  SUCCESS = 200, // 请求成功
}
